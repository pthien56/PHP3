<?php $__env->startSection('tieudetrang'); ?>
    <?php echo e($tenLoai); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('noidung'); ?>
    <h2 class="section-title">Chuyên mục: <?php echo e($tenLoai); ?></h2>
    <p class="section-subtitle">Danh sách bài viết mới nhất trong chuyên mục này.</p>

    <?php $__empty_1 = true; $__currentLoopData = $listtin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="news-card">
            <h3 class="news-card-title">
                <a href="<?php echo e(route('tin.chitiet', ['id' => $t->id])); ?>"><?php echo e($t->tieuDe); ?></a>
            </h3>

            <?php if(!empty($t->tomTat)): ?>
                <p class="news-card-summary"><?php echo e($t->tomTat); ?></p>
            <?php endif; ?>

            <?php if(!empty($t->ngayDang)): ?>
                <p class="news-card-meta">Đăng ngày: <?php echo e(\Illuminate\Support\Carbon::parse($t->ngayDang)->format('d/m/Y')); ?></p>
            <?php endif; ?>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="empty-state">Hiện chưa có tin trong chuyên mục này.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap3\resources\views/tintrongloai.blade.php ENDPATH**/ ?>