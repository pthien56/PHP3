<?php $__env->startSection('title', 'Tin má»›i'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="news-title">Top 10 tin má»›i nháº¥t</h2>

    <?php if($data->isEmpty()): ?>
        <p class="empty">KhÃ´ng cÃ³ dá»¯ liá»‡u Ä‘á»ƒ hiá»ƒn thá»‹.</p>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="news-item">
                <h3 class="news-title">
                    <a href="<?php echo e(route('tin.chitiet', ['id' => $tin->id])); ?>"><?php echo e($tin->tieuDe); ?></a>
                </h3>
                <p class="meta">NgÃ y Ä‘Äƒng: <?php echo e($tin->ngayDang); ?></p>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.news', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap3\resources\views\tinmoi.blade.php ENDPATH**/ ?>