<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php $__env->startSection('title', "Sửa danh mục sản phẩm"); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Sửa danh mục</h1>
    <form action="<?php echo e(route('categories.update', $category->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Tên danh mục</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="mb-3">
            <label class="form-label" for="status">Trạng thái</label>
            <select class="form-control" id="status" name="status" required>
                <option value="1" <?php echo e($category->status == 1 ? 'selected' : ''); ?>>Kích hoạt</option>
                <option value="0" <?php echo e($category->status == 0 ? 'selected' : ''); ?>>Vô hiệu hóa</option>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Cập nhật danh mục</button>
    </form>
</div>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap3\resources\views\categories\edit.blade.php ENDPATH**/ ?>