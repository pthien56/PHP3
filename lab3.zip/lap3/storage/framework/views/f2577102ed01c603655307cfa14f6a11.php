<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php $__env->startSection('title', "Thêm danh mục sản phẩm"); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Thêm danh mục</h1>
    <form action="<?php echo e(route('categories.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Tên danh mục</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="mb-3">
            <label class="form-label" for="status">Trạng thái</label>
            <input type="text" class="form-control" id="status" name="status" value="1">
        </div>
        <button type="submit" class="btn btn-success">Thêm danh mục</button>
    </form>
</div>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap3\resources\views\categories\create.blade.php ENDPATH**/ ?>