<?php $__env->startSection('tieudetrang'); ?>
    <?php echo e($tin->tieuDe); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('noidung'); ?>
    <article class="detail-article">
        <h2 class="detail-title"><?php echo e($tin->tieuDe); ?></h2>

        <?php if(!empty($tin->tomTat)): ?>
            <p class="detail-summary"><?php echo e($tin->tomTat); ?></p>
        <?php endif; ?>

        <?php if(!empty($tin->ngayDang)): ?>
            <p class="news-card-meta">Đăng ngày: <?php echo e(\Illuminate\Support\Carbon::parse($tin->ngayDang)->format('d/m/Y H:i')); ?></p>
        <?php endif; ?>

        <div class="detail-content">
            <?php echo $tin->noiDung; ?>

        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap3\resources\views\chitiet.blade.php ENDPATH**/ ?>