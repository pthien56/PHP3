<?php $__env->startSection('title', 'Chi tiáº¿t tin'); ?>

<?php $__env->startSection('content'); ?>
    <article>
        <h2 class="news-title"><?php echo e($tin->tieuDe); ?></h2>

        <?php if(!empty($tin->ngayDang)): ?>
            <p class="meta">NgÃ y Ä‘Äƒng: <?php echo e($tin->ngayDang); ?></p>
        <?php endif; ?>

        <?php if(!empty($tin->tomTat)): ?>
            <p class="summary"><strong>TÃ³m táº¯t:</strong> <?php echo e($tin->tomTat); ?></p>
        <?php endif; ?>

        <div class="detail-body"><?php echo $tin->noiDung; ?></div>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.news', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap3\resources\views\chitiettin.blade.php ENDPATH**/ ?>